import React from 'react'
import { Sparkles } from 'lucide-react'
import heroMockup from '@/assets/livro-e-smartphone-com-audiolivro-d985d.png'

export const HeroMockup: React.FC = () => {
  return (
    <div className="relative mx-auto max-w-md lg:max-w-lg">
      {/* Background soft glow (valoriza o recorte transparente da imagem) */}
      <div
        className="absolute -inset-6 rounded-[2.5rem] bg-gradient-to-r from-amber-200/50 via-orange-100/40 to-amber-100/50 blur-2xl -z-10"
        aria-hidden="true"
      />

      {/* Mockup principal: livro físico + smartphone com Audiolibro (imagem real) */}
      <figure className="relative">
        <img
          src={heroMockup}
          alt="Libro físico Habla en público con más confianza junto a un smartphone mostrando el audiolibro en español con botón Reproducir"
          className="w-full h-auto drop-shadow-[0_18px_35px_rgba(28,25,23,0.25)]"
          loading="eager"
          decoding="async"
        />

        {/* Badge flutuante sobre o mockup */}
        <span className="absolute top-3 left-3 inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-amber-100/95 text-amber-900 border border-amber-300 backdrop-blur-sm">
          <Sparkles className="w-3.5 h-3.5 text-amber-600" />
          Edición Completa Digital
        </span>
      </figure>

      {/* Nota de entrega (mantida do mockup anterior) */}
      <p className="mt-5 text-center text-[11px] font-medium text-stone-500">
        Descarga inmediata tras la compra · Compatible con PC, móvil y tablet
      </p>
    </div>
  )
}
